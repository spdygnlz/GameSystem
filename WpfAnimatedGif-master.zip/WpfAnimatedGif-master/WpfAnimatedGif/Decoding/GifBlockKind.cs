namespace WpfAnimatedGif.Decoding
{
    internal enum GifBlockKind
    {
        Control,
        GraphicRendering,
        SpecialPurpose,
        Other
    }
}
