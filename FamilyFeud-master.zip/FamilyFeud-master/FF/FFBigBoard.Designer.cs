﻿namespace FF
{
    partial class FFBigBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.StrikeOutbox = new System.Windows.Forms.PictureBox();
            this.StrikeDisplayTimer = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BBAnswer1 = new System.Windows.Forms.PictureBox();
            this.BBAnswer2 = new System.Windows.Forms.PictureBox();
            this.BBAnswer3 = new System.Windows.Forms.PictureBox();
            this.BBAnswer4 = new System.Windows.Forms.PictureBox();
            this.BBAnswer5 = new System.Windows.Forms.PictureBox();
            this.BBAnswer6 = new System.Windows.Forms.PictureBox();
            this.BBAnswer7 = new System.Windows.Forms.PictureBox();
            this.BBAnswer8 = new System.Windows.Forms.PictureBox();
            this.BBAnswer9 = new System.Windows.Forms.PictureBox();
            this.BBAnswer10 = new System.Windows.Forms.PictureBox();
            this.BBAnswer11 = new System.Windows.Forms.PictureBox();
            this.BBAnswer12 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.StrikeOutbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer12)).BeginInit();
            this.SuspendLayout();
            // 
            // StrikeOutbox
            // 
            this.StrikeOutbox.BackColor = System.Drawing.Color.Transparent;
            this.StrikeOutbox.Location = new System.Drawing.Point(289, 446);
            this.StrikeOutbox.Name = "StrikeOutbox";
            this.StrikeOutbox.Size = new System.Drawing.Size(455, 166);
            this.StrikeOutbox.TabIndex = 0;
            this.StrikeOutbox.TabStop = false;
            // 
            // StrikeDisplayTimer
            // 
            this.StrikeDisplayTimer.Interval = 1000;
            this.StrikeDisplayTimer.Tick += new System.EventHandler(this.StrikeDisplayTimer_Tick);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Courier New", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(431, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 89);
            this.label1.TabIndex = 1;
            this.label1.Text = "40";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Courier New", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(-6, 327);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(178, 89);
            this.label2.TabIndex = 2;
            this.label2.Text = "400";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Courier New", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(864, 328);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(178, 89);
            this.label3.TabIndex = 3;
            this.label3.Text = "401";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BBAnswer1
            // 
            this.BBAnswer1.Image = global::FF.Properties.Resources._0;
            this.BBAnswer1.Location = new System.Drawing.Point(281, 196);
            this.BBAnswer1.Name = "BBAnswer1";
            this.BBAnswer1.Size = new System.Drawing.Size(235, 37);
            this.BBAnswer1.TabIndex = 4;
            this.BBAnswer1.TabStop = false;
            // 
            // BBAnswer2
            // 
            this.BBAnswer2.Image = global::FF.Properties.Resources._0;
            this.BBAnswer2.Location = new System.Drawing.Point(281, 235);
            this.BBAnswer2.Name = "BBAnswer2";
            this.BBAnswer2.Size = new System.Drawing.Size(235, 37);
            this.BBAnswer2.TabIndex = 5;
            this.BBAnswer2.TabStop = false;
            // 
            // BBAnswer3
            // 
            this.BBAnswer3.Image = global::FF.Properties.Resources._0;
            this.BBAnswer3.Location = new System.Drawing.Point(281, 274);
            this.BBAnswer3.Name = "BBAnswer3";
            this.BBAnswer3.Size = new System.Drawing.Size(235, 37);
            this.BBAnswer3.TabIndex = 6;
            this.BBAnswer3.TabStop = false;
            // 
            // BBAnswer4
            // 
            this.BBAnswer4.Image = global::FF.Properties.Resources._0;
            this.BBAnswer4.Location = new System.Drawing.Point(281, 313);
            this.BBAnswer4.Name = "BBAnswer4";
            this.BBAnswer4.Size = new System.Drawing.Size(235, 37);
            this.BBAnswer4.TabIndex = 7;
            this.BBAnswer4.TabStop = false;
            // 
            // BBAnswer5
            // 
            this.BBAnswer5.Image = global::FF.Properties.Resources._0;
            this.BBAnswer5.Location = new System.Drawing.Point(281, 352);
            this.BBAnswer5.Name = "BBAnswer5";
            this.BBAnswer5.Size = new System.Drawing.Size(235, 37);
            this.BBAnswer5.TabIndex = 8;
            this.BBAnswer5.TabStop = false;
            // 
            // BBAnswer6
            // 
            this.BBAnswer6.Image = global::FF.Properties.Resources._0;
            this.BBAnswer6.Location = new System.Drawing.Point(281, 391);
            this.BBAnswer6.Name = "BBAnswer6";
            this.BBAnswer6.Size = new System.Drawing.Size(235, 37);
            this.BBAnswer6.TabIndex = 9;
            this.BBAnswer6.TabStop = false;
            // 
            // BBAnswer7
            // 
            this.BBAnswer7.Image = global::FF.Properties.Resources._0;
            this.BBAnswer7.Location = new System.Drawing.Point(520, 196);
            this.BBAnswer7.Name = "BBAnswer7";
            this.BBAnswer7.Size = new System.Drawing.Size(235, 37);
            this.BBAnswer7.TabIndex = 10;
            this.BBAnswer7.TabStop = false;
            // 
            // BBAnswer8
            // 
            this.BBAnswer8.Image = global::FF.Properties.Resources._0;
            this.BBAnswer8.Location = new System.Drawing.Point(520, 235);
            this.BBAnswer8.Name = "BBAnswer8";
            this.BBAnswer8.Size = new System.Drawing.Size(235, 37);
            this.BBAnswer8.TabIndex = 11;
            this.BBAnswer8.TabStop = false;
            // 
            // BBAnswer9
            // 
            this.BBAnswer9.Image = global::FF.Properties.Resources._0;
            this.BBAnswer9.Location = new System.Drawing.Point(520, 274);
            this.BBAnswer9.Name = "BBAnswer9";
            this.BBAnswer9.Size = new System.Drawing.Size(235, 37);
            this.BBAnswer9.TabIndex = 12;
            this.BBAnswer9.TabStop = false;
            // 
            // BBAnswer10
            // 
            this.BBAnswer10.Image = global::FF.Properties.Resources._0;
            this.BBAnswer10.Location = new System.Drawing.Point(520, 313);
            this.BBAnswer10.Name = "BBAnswer10";
            this.BBAnswer10.Size = new System.Drawing.Size(235, 37);
            this.BBAnswer10.TabIndex = 13;
            this.BBAnswer10.TabStop = false;
            // 
            // BBAnswer11
            // 
            this.BBAnswer11.Image = global::FF.Properties.Resources._0;
            this.BBAnswer11.Location = new System.Drawing.Point(520, 352);
            this.BBAnswer11.Name = "BBAnswer11";
            this.BBAnswer11.Size = new System.Drawing.Size(235, 37);
            this.BBAnswer11.TabIndex = 14;
            this.BBAnswer11.TabStop = false;
            // 
            // BBAnswer12
            // 
            this.BBAnswer12.Image = global::FF.Properties.Resources._0;
            this.BBAnswer12.Location = new System.Drawing.Point(520, 391);
            this.BBAnswer12.Name = "BBAnswer12";
            this.BBAnswer12.Size = new System.Drawing.Size(235, 37);
            this.BBAnswer12.TabIndex = 15;
            this.BBAnswer12.TabStop = false;
            // 
            // FFBigBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::FF.Properties.Resources.board;
            this.ClientSize = new System.Drawing.Size(1024, 768);
            this.Controls.Add(this.BBAnswer12);
            this.Controls.Add(this.BBAnswer11);
            this.Controls.Add(this.BBAnswer10);
            this.Controls.Add(this.BBAnswer9);
            this.Controls.Add(this.BBAnswer8);
            this.Controls.Add(this.BBAnswer7);
            this.Controls.Add(this.BBAnswer6);
            this.Controls.Add(this.BBAnswer5);
            this.Controls.Add(this.BBAnswer4);
            this.Controls.Add(this.BBAnswer3);
            this.Controls.Add(this.BBAnswer2);
            this.Controls.Add(this.BBAnswer1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.StrikeOutbox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FFBigBoard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FFBigBoard";
            this.Load += new System.EventHandler(this.FFBigBoard_Load);
            ((System.ComponentModel.ISupportInitialize)(this.StrikeOutbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BBAnswer12)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.PictureBox StrikeOutbox;
        public System.Windows.Forms.Timer StrikeDisplayTimer;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.PictureBox BBAnswer1;
        public System.Windows.Forms.PictureBox BBAnswer2;
        public System.Windows.Forms.PictureBox BBAnswer3;
        public System.Windows.Forms.PictureBox BBAnswer4;
        public System.Windows.Forms.PictureBox BBAnswer5;
        public System.Windows.Forms.PictureBox BBAnswer6;
        public System.Windows.Forms.PictureBox BBAnswer7;
        public System.Windows.Forms.PictureBox BBAnswer8;
        public System.Windows.Forms.PictureBox BBAnswer9;
        public System.Windows.Forms.PictureBox BBAnswer10;
        public System.Windows.Forms.PictureBox BBAnswer11;
        public System.Windows.Forms.PictureBox BBAnswer12;

    }
}